% This part was made by CEYLA KAYA , IRAJ NAYEBKHIL , NURSEITOVA SABINA

function LinearSolver(A, b)
    % LinearSolver solves the linear system Ax = b using three different methods
     % Check if the lengths are equal.
    if length(b) ~= size(A, 1)
        fprintf('Please use as input an array with length = number of rows in A\n');
        return; 
    end

    %% Method 1: Matrix Inversion
    % This method inverts the matrix A and multiplies it by b to find the solution.
    % It's straightforward but computationally intensive and less accurate for large systems.
    fprintf('Method 1: Using Matrix Inversion\n');
    tic;
    x1 = inv(A) * b;
    Time1 = toc;
    fprintf('Time : %.6f seconds\n', Time1);

    %% Method 2: Backslash Operator (\ or mldivide)
    % It's typically faster and more accurate than matrix inversion.
    fprintf('Method 2: Using Backslash Operator\n');
    tic;
    x2 = A \ b;
    Time2 = toc;
    fprintf('Time : %.6f seconds\n', Time2);

    %% Method 3: Using linsolve
    % It can be more efficient than the backslash operator in certain scenarios.
    fprintf('Method 3: Using linsolve\n');
    tic;
    x3 = linsolve(A, b);
    Time3 = toc;
    fprintf('Time : %.6f seconds\n', Time3);

  
    %% Checks if the solutions from all three methods are identical.
    isEqual = isequal(x1, x2, x3);
    if isEqual
        fprintf('All methods yield the same result.\n');
    else
        fprintf('Methods yield different results.\n');
    end

    %% Bar plot to display  time
    % Visual comparison of the time taken by each method using a bar plot.
    methods = {'Matrix Inversion', 'Backslash Operator', 'linsolve'};
    times = [Time1, Time2, Time3];
    bar(times);
    set(gca, 'XTickLabel', methods);
    xlabel('Solution Method');
    ylabel(' Time (seconds)');
    title(' Time for Linear System Solvers');
end
%The execution times indicate that the backslash operator and linsolve are much faster than matrix inversion, 
% with linsolve being the fastest for this particular system. 
