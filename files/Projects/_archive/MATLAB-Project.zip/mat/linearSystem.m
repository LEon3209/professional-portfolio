
 % This part was made by CEYLA KAYA , IRAJ NAYEBKHIL , NURSEITOVA SABINA
% Coefficients of the linear system
A = [10^4, 0.1^4, 100^4, 15^4, 23^4, 90^4;
     5.5^4, 0.8^4, 1^4, 2^4, 1^4, 8^4;
     103^4, 3.1^4, 2^4, 1^4, 1^4, 67^4;
     1^4, 2^4, 1^4, 9^4, 8^4, 0;
     22^4, 11^4, 11^4, 11^4, 11^4, 22^4;
     34^4, 76^4, 2^4, 0.4^4, 3^4, 2^4];

% Constants on the right-hand side
b = [104; 0.3; -11; -8.21; 1; 0];

% Solve the linear system
solution = LinearSolver(A, b);
